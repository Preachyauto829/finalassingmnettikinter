# Name: Ethan Tsui, Jayden Chan, Lina Zheng, Brandon Khuu
# Date: 12.12.2023
# Description: ScoreSync

from tkinter import *
import tkinter as tk
from tkinter.ttk import *
from tkinter import messagebox
from PIL import Image, ImageTk

root = tk.Tk()
root.title("Scoreboard")
root.geometry("650x350")

# Screen dimensions
width = root.winfo_screenwidth()
height = root.winfo_screenheight()

# Customization Screen
customization_screen = Frame(root)

def customization():
  customization_screen.pack(fill='both', expand=1)
  menuscreen.pack_forget()  # Hide the menuscreen


# Function to go back to the main menu
def back_to_menu():
  menuscreen.pack(fill='both', expand=1)
  customization_screen.pack_forget()  # Hide the customization screen

# Menu Background Image
menubgimage = ImageTk.PhotoImage(
    Image.open('Images/menubg.png').resize((650, 350)))

# Setting new screen
menuscreen = Frame(root)
menuscreen.pack(fill='both', expand=1)
main_screen_label = Label(menuscreen, image=menubgimage).place(x=-1, y=0)

# Start scoreboard button
scoredboard_screen = Frame(root)
samecolour = False
def startscoreboard():
  global p1name, p2name, ftnum, p1colour, p2colour
  # Same colour check
  if samecolour == False:
    # Reject same name or no name check
    if p1name != p2name or p1name != "" and p2name != "":
      # Scoreboard Screen
      scoredboard_screen.pack(fill='both', expand=1)
      customization_screen.pack_forget()  # Hide the menuscreen
      
      # Get inputs
      p1name = p1name.get()
      p2name = p2name.get()
      ftnum = ftnum.get()
    else:
      messagebox.showerror("Error", 
                           "You cannot use the same names or leave fields blank.")
  else:
    messagebox.showerror("Error", 
                         "You cannot use the same colour for both players.")

  # checks (DELETE)
  print(p1name)
  print(p2name)
  print(f"Game: first to {ftnum}")
  print(p1colour)
  print(p2colour)

# Reject same colour check
def colourcheck(colour):
  global p1colour, p2colour, samecolour
  p1colour = p1colourdef.get()
  p2colour = p2colourdef.get()
  if p1colour == p2colour:
    messagebox.showerror("Error", "You cannot use the same colour for both players.")
    samecolour = True
  else:
    samecolour = False
    pass

# Name input on customization screen
# Labels
# Name label
p1namelabel = tk.Label(customization_screen, 
                       text = "Player 1 name: ", 
                       font = ("Arial Black", 13, "italic"))
p2namelabel = tk.Label(customization_screen, 
                       text = "Player 2 name: ", 
                       font = ("Arial Black", 13, "italic"))
p1namelabel.place(x = 50, y = 50)
p2namelabel.place(x = 400, y = 50)

# First to Label
ftnumlabel = tk.Label(customization_screen,
                      text = "First to: ",
                      font = ("Arial Black", 13, "italic"))
ftnumlabel.place(x = 190, y = 215)

# User Input
# Name input
p1name = tk.Entry(customization_screen,
                 font = ("Arial", 10))
p2name = tk.Entry(customization_screen,
                 font = ("Arial", 10))
p1name.place(x = 50, y = 85)
p2name.place(x = 400, y = 85)

# Colour dropdown input
# Options list
colour = ["Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Brown",]
# Player 1 defult colour
p1colourdef = StringVar(customization_screen)
p1colourdef.set(colour[0])
# Player 2 defult colour
p2colourdef = StringVar(customization_screen)
p2colourdef.set(colour[1])
# p1 dropdown
# Colour change
p1colour = OptionMenu(customization_screen, 
                      p1colourdef,
                      "Red",
                      *colour,
                      command = colourcheck)

p2colour = OptionMenu(customization_screen, 
                      p2colourdef, 
                      "Blue",
                      *colour,
                      command = colourcheck)
p1colour.pack()
p2colour.pack()


# kids_CB = Combobox(menu, width = 5)
# kids_CB['values'] = quantities
# kids_CB.current(0)
# kids_CB.place(x = 304, y = 245)

# First to num input
ftnum = tk.Entry(customization_screen,
                 width = 3,
                 font = ("Arial", 15))
ftnum.place(x = 200, y = 250)

# Start Scoreboard Screen
startbtn = tk.Button(customization_screen, text = "Start Game", 
                     command = startscoreboard)
startbtn.pack()
startbtn.place(x = 175, y = 300)

# Back button on the customization screen
back_button = tk.Button(customization_screen,
                        text="Back to Menu",
                        command=back_to_menu)
back_button.place(x=10, y=300)

# Continue to customization button
startgamebtnimg = ImageTk.PhotoImage(Image.open('Images/continueimgbg.png'))
startgamebutton = tk.Button(menuscreen,
                            text="Start Game",
                            command=customization,
                            image=startgamebtnimg,
                            bd=0,
                            borderwidth=0)
startgamebutton.place(x=60, y=130)

# Load game button
def loadgame():
  print("load game")

loadgamebtnimg = ImageTk.PhotoImage(Image.open('Images/loadbutton.png'))
loadgamebutton = tk.Button(menuscreen,
                           text="Load Game",
                           command=loadgame,
                           image=loadgamebtnimg,
                           bg="black",
                           highlightthickness=0)
loadgamebutton.place(x=57, y=160)

if "load game":
  print("hi")



# Scoreboard Screen
deletelabel = tk.Label(scoredboard_screen, text = "YAY :D", font = ("Arial, 100"))
deletelabel.pack()

# Exit game button
def exitgame():
  # Confirm closing program
  msg_box = tk.messagebox.askquestion('Exit Application', 
                                      'Are you sure you want to exit the application?',
                                      icon = 'warning')
  if msg_box == 'yes':
    exit()
  else:
    tk.messagebox.showinfo('Return', 'You will now return to the menu screen')

exitgamebtnimg = ImageTk.PhotoImage(Image.open('Images/exitbutton.png'))
exitgamebutton = tk.Button(menuscreen,
                           text="Exit Game",
                           command=exitgame,
                           image=exitgamebtnimg,
                           bg="black")
exitgamebutton.place(x=60, y=200)

# Closing Window
root.protocol("WM_DELETE_WINDOW", exitgame)

root.mainloop()
